package com.example.product.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.product.business.ProductService;
import com.example.product.model.Product;

@RestController
@RequestMapping("/api/product")
@CrossOrigin // for front end to allow unknown backends
public class ProductController {
	
	private ProductService productservice;
	
	@Autowired
	public ProductController(ProductService productservice) {
		super();
		this.productservice = productservice;
	}
	
	@GetMapping("/getAll")
	public List<Product> getAll(){
		return this.productservice.getAll();
	}
	
	
	@PostMapping("/addProduct")
	public Product createProd(@RequestBody Product product) {
		return this.productservice.saveProduct(product);
	}
	
	@PutMapping("/updateProduct/{id}")
	public Product updateProd(@PathVariable int id, @RequestBody Product prod) {
		prod.setId(id); // since we set id save method will update.
		return productservice.updateProduct(prod);
	}
	
	@DeleteMapping("/deleteProd")
	public void deleteProduct(@RequestParam int id) {
		productservice.deleteProductbyId(id);
	}
	
	@GetMapping("/filterByName")
	public List<Product> getProductByName(@RequestParam String name){
		return this.productservice.getProductsByName(name);
	}
	
	@GetMapping("filterByKeyword")
	public List<Product> getProductByKeyword(@RequestParam String keyword){
		return this.productservice.getProductsByKeyword(keyword);
	}

}
