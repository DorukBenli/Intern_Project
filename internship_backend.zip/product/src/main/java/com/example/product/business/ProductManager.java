package com.example.product.business;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.product.dao.CustomerDao;
import com.example.product.dao.ProductDao;
import com.example.product.model.Product;

@Service //automatically detects this class as an implementer
public class ProductManager implements ProductService{

	private ProductDao productdao;
	
	
	@Autowired //dependency injection.
	public ProductManager(ProductDao productdao, CustomerDao customerdao) {
		super();
		this.productdao=productdao;
	}
	@Override
	public List<Product> getAll() {
		return this.productdao.findAll();
	}
	@Override
	public Product saveProduct(Product prod) {
		return this.productdao.save(prod);
	}
	@Override
	public Product updateProduct(Product product) {
		//will contain id, if id does not exists will create a new product.
		return productdao.save(product);
	}
	@Override
	public void deleteProductbyId(int id) {
		this.productdao.deleteById(id);
	}
	@Override
	public List<Product> getProductsByName(String name) {
		return this.productdao.findByName(name);
	}
	@Override
	public List<Product> getProductsByKeyword(String keyword) {
		return this.productdao.findByNameContaining(keyword);
	}
}
