package com.example.product.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.product.business.CustomerService;
import com.example.product.model.Customer;
import com.example.product.model.Product;

@RestController
@RequestMapping("api/customer")
@CrossOrigin
public class CustomerController {

	private CustomerService customerservice;
	
	@Autowired
	public CustomerController(CustomerService customerservice) {
		super();
		this.customerservice = customerservice;
	}
	
	@GetMapping("/getcustomers")
	public List<Customer> getallCustomers(){
		return this.customerservice.getAll();
	}
	
	@PostMapping("/addCustomer")
	public Customer createProd(@RequestBody Customer cust) {
		return this.customerservice.saveCustomer(cust);
	}
	
	@PutMapping("/updateCustomer/{id}")
	public Customer updatecustomer(@PathVariable int id, @RequestBody Customer customer) {
		customer.setId(id);
		return this.customerservice.updateCustomer(customer);
	}
	@PutMapping("/{customerid}/product/{productid}")
	public Customer addToCart(@PathVariable int customerid, @PathVariable int productid) {
		return this.customerservice.addProductToList(productid, customerid);
	}
	
}
