package com.example.product.business;

import java.util.List;

import com.example.product.model.Product;

public interface ProductService {
	
	public List<Product> getAll();
	
	public Product saveProduct(Product prod);
	
	public Product updateProduct(Product product);
	
	public void deleteProductbyId(int id);
	
	public List<Product> getProductsByName(String name);
	
	public List<Product> getProductsByKeyword(String keyword);
	
	
}
