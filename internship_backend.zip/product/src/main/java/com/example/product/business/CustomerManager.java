package com.example.product.business;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.product.dao.CustomerDao;
import com.example.product.dao.ProductDao;
import com.example.product.model.Customer;
import com.example.product.model.Product;

@Service
public class CustomerManager implements CustomerService{
	
	private CustomerDao customerdao;
	
	private ProductDao productdao;
	
	// for dependency injection
	@Autowired
	public CustomerManager(CustomerDao customerdao, ProductDao productdao) {
		super();
		this.customerdao = customerdao;
		this.productdao = productdao;
	}

	@Override
	public List<Customer> getAll() {
		return this.customerdao.findAll();
	}

	@Override
	public Customer saveCustomer(Customer customer) {
		return this.customerdao.save(customer);
	}

	@Override
	public Optional<Customer> getCustomerById(int id) {
		return this.customerdao.findById(id);
	}

	@Override
	public Customer updateCustomer(Customer customer) {
		return this.customerdao.save(customer);
	}
	public Customer addProductToList(int prodid, int customerid){
		Product prod = productdao.findById(prodid).get();
		Customer cust = customerdao.findById(customerid).get();
		cust.addProductToCart(prod);
		return customerdao.save(cust);
		
	}
	
}
