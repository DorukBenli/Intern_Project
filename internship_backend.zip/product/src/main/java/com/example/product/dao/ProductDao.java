package com.example.product.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.example.product.model.Product;

public interface ProductDao extends JpaRepository<Product,Integer>{

	List<Product>findByName(String name);
	
	List<Product> findByNameContaining(String keyword);
}
