package com.example.product.business;

import java.util.List;
import java.util.Optional;

import com.example.product.model.Customer;
import com.example.product.model.Product;

public interface CustomerService {
	public List<Customer> getAll();
	
	public Customer saveCustomer(Customer customer);
	
	public Optional<Customer> getCustomerById(int id);
	
	public Customer updateCustomer(Customer customer);
	
	public Customer addProductToList(int prodid, int customerid);
	
}
